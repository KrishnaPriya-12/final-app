import { CustomerDTO } from './customer-dto';

describe('CustomerDTO', () => {
  it('should create an instance', () => {
    expect(new CustomerDTO()).toBeTruthy();
  });
});
