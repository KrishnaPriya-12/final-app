import { SeedDto } from './seed-dto';

describe('SeedDto', () => {
  it('should create an instance', () => {
    expect(new SeedDto()).toBeTruthy();
  });
});
