import { PlanterDto } from './planter-dto';

describe('PlanterDto', () => {
  it('should create an instance', () => {
    expect(new PlanterDto()).toBeTruthy();
  });
});
