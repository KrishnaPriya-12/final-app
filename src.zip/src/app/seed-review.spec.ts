import { SeedReview } from './seed-review';

describe('SeedReview', () => {
  it('should create an instance', () => {
    expect(new SeedReview()).toBeTruthy();
  });
});
